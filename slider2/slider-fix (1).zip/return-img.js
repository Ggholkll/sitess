    	  
let allVideos=document.querySelectorAll('video')
allVideos.forEach((vidElement) => {
  vidElement.addEventListener("ended", (event) => {
    vidElement.classList.add("mpp-hidden")
  })
})

