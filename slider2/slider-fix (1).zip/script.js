jQuery(function($){
    
    function processSlidesOrigin() {
      const realWidth = this.offsetWidth;
      const rect = this.getBoundingClientRect();
      const slide = $(this);
      slide.removeClass("firster laster");
      if(rect.left < realWidth) {
        slide.addClass("firster");
      } else if(rect.right > (window.innerWidth - realWidth)) {
        slide.addClass("laster");
      }
    }
    
    function registerSlidesOrigin() {
      $(this).find('.slick-slide').each(function(_, slide) {
        $(slide).off('mouseenter touchstart', processSlidesOrigin).on('mouseenter touchstart', processSlidesOrigin);
      });
    }
    
    function addMuteListener() {
      $(".flickfeed .mute-video").click(function () {
        if ($(".flickfeed video").prop('muted')) {
          $(".flickfeed video").prop('muted', false);
          $('.flickfeed .mute-video').addClass('unmute-video');

        } else {
          $(".flickfeed video").prop('muted',true);
          $('.flickfeed .mute-video').removeClass('unmute-video');
        }
      });
    }
    
    function mobilePauseVideo() {
      if (window.innerWidth <= 480) {
        $(".slick-current video")[0].pause();
      }
    }
    
    $('.flickfeed').on('init', registerSlidesOrigin);   
    $('.flickfeed').on('init', addMuteListener);   
    $('.flickfeed').on('afterChange', registerSlidesOrigin);
    $('.flickfeed').on('beforeChange', mobilePauseVideo);
    $('.flickfeed').on('breakpoint', addMuteListener);

    	  



    function getSliderSettings(){
        return {
          dots: true,
          centerMode: true,
          centerPadding: '40px',
          speed: 300,
          slidesToShow: 6,
          slidesToScroll: 6,
          forceSlidesToScroll: true,
          responsive: [
            {
              breakpoint: 1400,
              settings: {
                slidesToShow: 4,
                slidesToScroll: 4
              }
            },
            {
              breakpoint: 1024,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 3

              }
            },
            {
              breakpoint: 768,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 2
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            }
            // You can unslick at a given breakpoint now by adding:
            // settings: "unslick"
            // instead of a settings object
          ]
        }
    }
   
    $('.flickfeed').slick(getSliderSettings());

    /*$( ".slick-slide" ).on("mouseenter touchstart", function() {
              
       if ($(this).hasClass("firster")) {
         //  console.log('firster');
           var hoverslide = $(this);
            $(hoverslide).nextAll().addClass('furthernextslides');
          //  $(hoverslide).prevAll().addClass('prevslides'); 
        
       }else if ($(this).hasClass("laster")){
           var hoverslide = $(this);
            $(hoverslide).prevAll().addClass('furtherprevslides');
        }else{
             var hoverslide = $(this);
            $(hoverslide).nextAll().addClass('nextslides');
            $(hoverslide).prevAll().addClass('prevslides'); 
        }
        
      
    });
	
	
    
    $( ".slick-slide" ).on("mouseleave touchend", function() {
      $(this).parent().find( ".slick-slide" ).removeClass('nextslides');
    $(this).parent().find( ".slick-slide" ).removeClass('prevslides');
      $(this).parent().find( ".slick-slide" ).removeClass('furthernextslides');
      $(this).parent().find( ".slick-slide" ).removeClass('furtherprevslides');
    });*/
let allVideos=document.querySelectorAll('video')
allVideos.forEach((vidElement) => {
  vidElement.addEventListener("ended", (event) => {
    vidElement.classList.add("mpp-hidden")
  })
})



 
});

